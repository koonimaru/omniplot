
    #        /\   /\\
    #       / \  / \\
    #    @@@@@@@@@@@@@@
    #   @@@@@@@@@@@@@@@@
    #    (  ---  ---   )
    #    (   O L  O    )3
    #     (   <--->   )
    #      `---------'
    #     /             \  
    #    /  /|        |\ \\
    #        |        |
from omniplot._version import __version__
__pdoc__ = {'chipseq_utils': False, 
            "cython_utils": False, 
            "plot_classes":False, 
            "utils":False,
            "statistics":False,
            "regressionplot":False,
            "data":False,
              "igraph_classes":False}